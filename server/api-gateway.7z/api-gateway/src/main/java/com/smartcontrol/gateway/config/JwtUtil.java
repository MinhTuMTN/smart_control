package com.smartcontrol.gateway.config;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.SignedJWT;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secretKey;

    public SignedJWT verifyToken(String token) throws JOSEException, ParseException {
        JWSVerifier verifier = new MACVerifier(secretKey.getBytes());
        SignedJWT signedJWT = SignedJWT.parse(token);

        Date expirationDate = signedJWT.getJWTClaimsSet().getExpirationTime();
        if (expirationDate.before(new Date())) {
           throw new RuntimeException("Token has expired");
        }

        if (!signedJWT.verify(verifier)) {
            throw new RuntimeException("Invalid token signature");
        }

        return signedJWT;
    }
    
}
