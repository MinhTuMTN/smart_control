package com.smartcontrol.gateway.config;

import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.stereotype.Component;

@Component
public class AppJwtDecoder implements JwtDecoder {

    private final JwtUtil jwtProvider;
    private final NimbusJwtDecoder nimbusJwtDecoder;


    public AppJwtDecoder(JwtUtil jwtProvider, NimbusJwtDecoder nimbusJwtDecoder) {
        this.jwtProvider = jwtProvider;
        this.nimbusJwtDecoder = nimbusJwtDecoder;
    }


    @Override
    public Jwt decode(String token) throws JwtException {
        try {
            jwtProvider.verifyToken(token);
        } catch (Exception e) {
            throw new JwtException(e.getMessage());
        }

        return nimbusJwtDecoder.decode(token);
    }
    
}
