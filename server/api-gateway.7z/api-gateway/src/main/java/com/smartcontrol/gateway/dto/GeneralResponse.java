package com.smartcontrol.gateway.dto;

import lombok.Data;
import lombok.Builder;

@Data
@Builder
public class GeneralResponse {
    private String message;
    private Object data;    
}
